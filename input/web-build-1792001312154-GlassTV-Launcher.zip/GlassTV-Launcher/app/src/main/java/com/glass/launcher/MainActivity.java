package com.glass.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.SearchManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int PICK_WALLPAPER = 42;
    private SharedPreferences prefs;
    private LinearLayout root, header, appRows;
    private GridLayout grid;
    private EditText search;
    private TextView clock, date, status;
    private List<AppEntry> allApps = new ArrayList<>();
    private String query = "";
    private boolean favoritesOnly = false;

    static class AppEntry {
        String label, pkg;
        Drawable icon;
        AppEntry(String l, String p, Drawable i) { label=l; pkg=p; icon=i; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("glass_tv", MODE_PRIVATE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        buildUI(); loadWallpaper(); loadApps(); renderApps(); updateClock();
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable shape(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke); return d;
    }
    private TextView text(String value, float size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        t.setGravity(Gravity.CENTER_VERTICAL); t.setFocusable(false); return t;
    }
    private Button button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(14);
        b.setAllCaps(false); b.setBackgroundResource(com.glass.launcher.R.drawable.glass_button);
        b.setPadding(dp(12), dp(4), dp(12), dp(4)); b.setFocusable(true);
        b.setOnClickListener(v -> action.run());
        b.setOnFocusChangeListener((v, focused) -> { v.animate().scaleX(focused?1.045f:1f).scaleY(focused?1.045f:1f).setDuration(130).start(); });
        return b;
    }

    private void buildUI() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(42),dp(26),dp(42),dp(24));
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF18243A,0xFF0B1020,0xFF090D17}));
        setContentView(root);
        header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout titleBox = new LinearLayout(this); titleBox.setOrientation(LinearLayout.VERTICAL);
        TextView brand = text("GLASS", 15, 0xFFB9D5FF, true); brand.setLetterSpacing(.22f);
        clock = text("--:--", 38, Color.WHITE, true); date = text("", 14, 0xFFD1D9E8, false);
        titleBox.addView(brand); titleBox.addView(clock); titleBox.addView(date);
        header.addView(titleBox, new LinearLayout.LayoutParams(0, -2, 1));
        Button settings = button("⚙  Settings", this::showSettings); header.addView(settings);
        Button fav = button(favoritesOnly ? "All apps" : "★ Favorites", () -> { favoritesOnly=!favoritesOnly; renderApps(); });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-2, dp(48)); bp.leftMargin=dp(10); header.addView(fav,bp);
        root.addView(header);

        LinearLayout searchRow = new LinearLayout(this); searchRow.setGravity(Gravity.CENTER_VERTICAL); searchRow.setPadding(0,dp(18),0,dp(12));
        search = new EditText(this); search.setSingleLine(true); search.setTextColor(Color.WHITE); search.setHintTextColor(0xFFB3BED0); search.setHint("Search apps…");
        search.setTextSize(17); search.setPadding(dp(18),0,dp(18),0); search.setBackground(shape(0xAA202B40,0x55FFFFFF,18));
        search.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
        search.addTextChangedListener(new android.text.TextWatcher(){ public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){query=s.toString().trim().toLowerCase(Locale.ROOT);renderApps();} public void afterTextChanged(android.text.Editable e){} });
        searchRow.addView(search,new LinearLayout.LayoutParams(dp(520),dp(48))); root.addView(searchRow);
        status = text("YOUR APPS", 12, 0xFFB9D5FF, true); status.setLetterSpacing(.16f); status.setPadding(dp(2),dp(4),0,dp(10)); root.addView(status);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(false); scroll.setClipToPadding(false);
        grid = new GridLayout(this); grid.setColumnCount(5); grid.setAlignmentMode(GridLayout.ALIGN_BOUNDS); grid.setUseDefaultMargins(false);
        grid.setPadding(0,0,0,dp(12)); scroll.addView(grid); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        TextView footer=text("Use the remote to navigate  ·  OK to open  ·  Settings to personalize",12,0xFF9DAAC0,false);
        footer.setPadding(dp(2),dp(10),0,0); root.addView(footer);
    }

    private void updateClock() {
        if (clock != null) {
            clock.setText(new SimpleDateFormat("h:mm", Locale.getDefault()).format(new Date()));
            date.setText(new SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(new Date()));
        }
        clock.postDelayed(this::updateClock, 30000);
    }

    private void loadApps() {
        allApps.clear(); PackageManager pm=getPackageManager();
        Intent intent=new Intent(Intent.ACTION_MAIN); intent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> found=pm.queryIntentActivities(intent,0);
        Set<String> seen=new HashSet<>();
        for (ResolveInfo r:found) {
            String pkg=r.activityInfo.packageName;
            if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
            try { allApps.add(new AppEntry(r.loadLabel(pm).toString(),pkg,r.loadIcon(pm))); } catch(Exception ignored){}
        }
        Collections.sort(allApps, Comparator.comparing(a -> a.label.toLowerCase(Locale.ROOT)));
    }

    private void renderApps() {
        if (grid == null) return;
        grid.removeAllViews(); int cols = prefs==null?5:prefs.getInt("columns",5); grid.setColumnCount(Math.max(3,Math.min(7,cols)));
        Set<String> favorites=prefs==null?new HashSet<>():prefs.getStringSet("favorites",new HashSet<>());
        List<AppEntry> list=new ArrayList<>();
        for(AppEntry a:allApps) {
            if(!a.label.toLowerCase(Locale.ROOT).contains(query) && !a.pkg.toLowerCase(Locale.ROOT).contains(query)) continue;
            if(favoritesOnly && !favorites.contains(a.pkg)) continue;
            list.add(a);
        }
        if(prefs!=null && prefs.getBoolean("favoritesFirst",true)) list.sort((a,b)-> {boolean af=favorites.contains(a.pkg),bf=favorites.contains(b.pkg); if(af!=bf)return af?-1:1; return a.label.compareToIgnoreCase(b.label);});
        status.setText((favoritesOnly?"FAVORITES":"YOUR APPS")+"  ·  "+list.size()+" apps");
        int colsNow=grid.getColumnCount(); int width=(int)(getResources().getDisplayMetrics().widthPixels/(float)colsNow)-dp(18);
        for(AppEntry a:list) {
            LinearLayout tile=new LinearLayout(this); tile.setOrientation(LinearLayout.VERTICAL); tile.setGravity(Gravity.CENTER); tile.setFocusable(true); tile.setClickable(true);
            tile.setPadding(dp(8),dp(12),dp(8),dp(12)); tile.setBackground(shape(0x77242F44,0x44FFFFFF,20));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(Math.max(dp(105),width),dp(130)); lp.setMargins(dp(5),dp(5),dp(5),dp(5));
            ImageView icon=new ImageView(this); icon.setImageDrawable(a.icon); icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            tile.addView(icon,new LinearLayout.LayoutParams(dp(48),dp(48)));
            TextView label=text(a.label,13,Color.WHITE,true); label.setGravity(Gravity.CENTER); label.setMaxLines(2); label.setEllipsize(android.text.TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams tlp=new LinearLayout.LayoutParams(-1,dp(38)); tlp.topMargin=dp(8); tile.addView(label,tlp);
            tile.setOnFocusChangeListener((v,focused)->{v.setBackground(shape(focused?0xDDEAF3FF:0x77242F44,focused?Color.WHITE:0x44FFFFFF,20)); v.animate().scaleX(focused?1.05f:1f).scaleY(focused?1.05f:1f).setDuration(130).start();});
            tile.setOnClickListener(v->launchApp(a.pkg));
            tile.setOnLongClickListener(v->{showAppOptions(a);return true;});
            grid.addView(tile,lp);
        }
        if(list.isEmpty()) { TextView empty=text(favoritesOnly?"No favorites yet. Long-press an app to add one.":"No matching apps found.",17,0xFFD1D9E8,false); empty.setPadding(dp(16),dp(24),0,dp(24)); grid.addView(empty); }
    }

    private void launchApp(String pkg) {
        try { Intent i=getPackageManager().getLaunchIntentForPackage(pkg); if(i==null) throw new ActivityNotFoundException(); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); }
        catch(Exception e){Toast.makeText(this,"This app cannot be opened on this device.",Toast.LENGTH_SHORT).show();}
    }
    private void showAppOptions(AppEntry a) {
        Set<String> set=new HashSet<>(prefs.getStringSet("favorites",new HashSet<>())); boolean is=set.contains(a.pkg);
        new AlertDialog.Builder(this).setTitle(a.label).setItems(new String[]{is?"Remove from favorites":"Add to favorites","Open app","App info"},(d,w)->{
            if(w==0){if(is)set.remove(a.pkg);else set.add(a.pkg);prefs.edit().putStringSet("favorites",set).apply();renderApps();}
            else if(w==1)launchApp(a.pkg); else if(w==2){Intent i=new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+a.pkg));startActivity(i);}
        }).show();
    }

    private void showSettings() {
        String[] options={"Choose wallpaper","Remove custom wallpaper","Number of app columns","Favorites appear first","Manage favorites","System settings","About Glass TV"};
        new AlertDialog.Builder(this).setTitle("Glass TV · Settings").setItems(options,(d,which)->{
            switch(which){case 0: chooseWallpaper();break; case 1:prefs.edit().remove("wallpaper").apply();loadWallpaper();break;
                case 2: chooseColumns();break; case 3:prefs.edit().putBoolean("favoritesFirst",!prefs.getBoolean("favoritesFirst",true)).apply();renderApps();Toast.makeText(this,"Favorites-first: "+prefs.getBoolean("favoritesFirst",true),Toast.LENGTH_SHORT).show();break;
                case 4: favoritesOnly=true;renderApps();break; case 5:try{startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));}catch(Exception e){}break;
                case 6:new AlertDialog.Builder(this).setTitle("Glass TV 1.0").setMessage("A customizable, remote-friendly glass launcher. Designed for Android 9 (API 28) and newer.").setPositiveButton("OK",null).show();break;}
        }).show();
    }
    private void chooseColumns() {
        String[] labels={"3 columns","4 columns","5 columns","6 columns","7 columns"};
        new AlertDialog.Builder(this).setTitle("Apps per row").setSingleChoiceItems(labels,prefs.getInt("columns",5)-3,(d,which)->{prefs.edit().putInt("columns",which+3).apply();d.dismiss();renderApps();}).setNegativeButton("Cancel",null).show();
    }
    private void chooseWallpaper() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*");
        try{startActivityForResult(i,PICK_WALLPAPER);}catch(Exception e){Toast.makeText(this,"Image picker unavailable.",Toast.LENGTH_SHORT).show();}
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_WALLPAPER && resultCode==RESULT_OK && data!=null && data.getData()!=null){
            Uri uri=data.getData(); try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);prefs.edit().putString("wallpaper",uri.toString()).apply();loadWallpaper();}
            catch(Exception e){Toast.makeText(this,"Could not save wallpaper access. Try another image.",Toast.LENGTH_LONG).show();}
        }
    }
    private void loadWallpaper() {
        if(root==null)return; String uriText=prefs.getString("wallpaper",null);
        if(uriText==null){root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xFF263A57,0xFF10182A,0xFF080C16}));return;}
        try(InputStream in=getContentResolver().openInputStream(Uri.parse(uriText))){
            android.graphics.Bitmap bmp=BitmapFactory.decodeStream(in); if(bmp!=null){BitmapDrawable bd=new BitmapDrawable(getResources(),bmp);bd.setGravity(Gravity.FILL);root.setBackground(new android.graphics.drawable.LayerDrawable(new Drawable[]{bd,new android.graphics.drawable.ColorDrawable(0x99070C18)}));}
        }catch(Exception e){prefs.edit().remove("wallpaper").apply();root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xFF263A57,0xFF10182A,0xFF080C16}));}
    }
    @Override public boolean onKeyDown(int keyCode,KeyEvent event) {
        if(keyCode==KeyEvent.KEYCODE_MENU){showSettings();return true;}
        if(keyCode==KeyEvent.KEYCODE_SEARCH){search.requestFocus();return true;}
        if(keyCode==KeyEvent.KEYCODE_BACK && search.hasFocus() && search.length()>0){search.setText("");return true;}
        return super.onKeyDown(keyCode,event);
    }
    @Override protected void onResume(){super.onResume(); if(prefs!=null){loadApps();renderApps();}}
}
